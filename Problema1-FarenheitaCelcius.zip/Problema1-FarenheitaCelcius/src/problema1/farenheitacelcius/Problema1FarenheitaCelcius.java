package problema1.farenheitacelcius;

import javax.swing.JOptionPane;


public class Problema1FarenheitaCelcius {

    
    public static void main(String[] args) {
      double C, F;
      
      F =Float.parseFloat(JOptionPane.showInputDialog("Favor ingresar la temperatura en valores Farenheit"));
      C = (F-32)*5/9
       
              JOptionPane.showMessageDialog(null, "Su temperatura en Celcius es: "+C);
      
      
      
      
    }
    
}
